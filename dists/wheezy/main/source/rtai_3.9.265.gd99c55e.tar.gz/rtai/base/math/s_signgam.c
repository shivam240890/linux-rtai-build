#include "math.h"
#include "mathP.h"
int signgam = 0;
