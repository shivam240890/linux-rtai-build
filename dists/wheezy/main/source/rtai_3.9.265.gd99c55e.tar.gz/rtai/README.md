RTAI
====

Welcome to the `master` branch of the RTAI repository!

This branch has many additional features, bug fixes,
performance enhancements, and many other things that
are NOT supported by the official RTAI developers.

This branch is where the latest, bleeding edge code takes place.

This repository does not keep track of RTAI's history before
version 3.9, which is the initial commit of this repository.

Branches `magma` and `vulcano` track the official CVS
branches of the upstream RTAI repository.

Please refer to the README.INSTALL file for building instructions.
