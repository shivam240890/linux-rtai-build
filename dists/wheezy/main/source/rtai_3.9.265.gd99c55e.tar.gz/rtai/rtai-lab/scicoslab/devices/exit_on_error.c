void exit_on_error(void)
{
  exit(1);
}
